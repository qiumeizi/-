# 境之视界 - 智能商业分析平台后端服务

## 项目简介

境之视界是一个基于AI的智能商业分析平台，专注于为企业提供商业模式分析、投资决策支持和文档智能处理服务。本项目是平台的后端服务，采用Node.js + TypeScript + Koa框架构建。

## 核心功能

- 📄 **文档智能处理**: 支持PDF、Word、Excel等格式文档的上传和OCR识别
- 🧠 **商业模式分析**: 基于AI的商业模式分析和行业模板匹配
- 💰 **投资计算**: PP、IRR、NPV等投资回报指标计算
- 🔐 **用户认证**: JWT基础的用户认证和权限管理
- 📊 **数据可视化**: 支持思维导图和图表的数据可视化
- 🗄️ **多数据源**: PostgreSQL + Redis + MinIO的混合存储架构

## 技术栈

- **运行时**: Node.js 18+
- **语言**: TypeScript
- **框架**: Koa.js
- **数据库**: PostgreSQL 15
- **缓存**: Redis 7
- **对象存储**: MinIO
- **认证**: JWT
- **文档处理**: Multer + OCR
- **容器化**: Docker + Docker Compose

## 项目结构

```
backend/
├── src/
│   ├── config/          # 配置文件
│   │   ├── database.ts   # 数据库配置
│   │   ├── redis.ts      # Redis配置
│   │   ├── minio.ts      # MinIO配置
│   │   └── logger.ts     # 日志配置
│   ├── middleware/       # 中间件
│   │   ├── auth.ts       # 认证中间件
│   │   ├── cors.ts       # CORS中间件
│   │   └── errorHandler.ts # 错误处理中间件
│   ├── models/          # 数据模型
│   │   ├── User.ts       # 用户模型
│   │   ├── File.ts       # 文件模型
│   │   └── Analysis.ts   # 分析模型
│   ├── routes/          # 路由
│   │   ├── index.ts      # 路由入口
│   │   ├── auth.ts       # 认证路由
│   │   ├── upload.ts     # 文件上传路由
│   │   ├── analysis.ts   # 分析路由
│   │   ├── users.ts      # 用户管理路由
│   │   └── health.ts     # 健康检查路由
│   ├── services/        # 业务服务
│   │   ├── authService.ts    # 认证服务
│   │   ├── fileService.ts    # 文件服务
│   │   ├── analysisService.ts # 分析服务
│   │   └── ocrService.ts     # OCR服务
│   ├── utils/           # 工具函数
│   │   ├── errors.ts     # 错误处理
│   │   ├── validation.ts # 数据验证
│   │   └── fileHandler.ts # 文件处理
│   ├── types/           # 类型定义
│   ├── app.ts           # 应用入口
│   └── server.ts        # 服务器启动
├── tests/               # 测试文件
├── logs/                # 日志文件
├── uploads/             # 本地上传文件
├── scripts/             # 脚本文件
├── docker-compose.yml   # Docker Compose配置
├── Dockerfile           # Docker配置
├── package.json         # 项目依赖
├── tsconfig.json        # TypeScript配置
├── .env.example         # 环境变量模板
└── README.md           # 项目文档
```

## 快速开始

### 环境要求

- Node.js 18.0+
- npm 8.0+
- PostgreSQL 15+
- Redis 7+
- MinIO (可选，用于对象存储)

### 安装步骤

1. **克隆项目**
```bash
git clone <repository-url>
cd vision-insight/backend
```

2. **安装依赖**
```bash
npm install
```

3. **配置环境变量**
```bash
cp .env.example .env
# 编辑 .env 文件，配置数据库、Redis、MinIO等连接信息
```

4. **启动数据库服务**
```bash
# 使用Docker Compose启动所有服务
docker-compose up -d postgres redis minio

# 或者手动启动各个服务
```

5. **运行数据库迁移**
```bash
npm run db:migrate
npm run db:seed
```

6. **启动开发服务器**
```bash
npm run dev
```

服务将在 `http://localhost:3000` 启动。

### Docker部署

使用Docker Compose一键部署完整服务栈：

```bash
# 启动所有服务
docker-compose up -d

# 查看服务状态
docker-compose ps

# 查看日志
docker-compose logs -f backend

# 停止服务
docker-compose down
```

## API文档

### 认证接口

- `POST /api/auth/register` - 用户注册
- `POST /api/auth/login` - 用户登录
- `POST /api/auth/logout` - 用户登出
- `POST /api/auth/refresh` - 刷新Token
- `GET /api/auth/me` - 获取当前用户信息

### 文件上传接口

- `POST /api/upload/single` - 单文件上传
- `POST /api/upload/multiple` - 多文件上传
- `GET /api/upload/files` - 获取文件列表
- `GET /api/upload/files/:id` - 获取文件详情
- `GET /api/upload/download/:id` - 下载文件
- `DELETE /api/upload/files/:id` - 删除文件

### 分析接口

- `POST /api/analysis/document` - 文档分析
- `GET /api/analysis/result/:id` - 获取分析结果
- `POST /api/analysis/business-model` - 商业模式分析
- `POST /api/analysis/investment` - 投资计算
- `GET /api/analysis/history` - 获取分析历史

### 健康检查

- `GET /api/health` - 基础健康检查
- `GET /api/health/detailed` - 详细健康检查
- `GET /api/health/ready` - 就绪检查
- `GET /api/health/live` - 存活检查

## 开发指南

### 代码规范

项目使用ESLint + Prettier进行代码格式化：

```bash
# 检查代码规范
npm run lint

# 自动修复代码规范问题
npm run lint:fix

# 格式化代码
npm run format
```

### 测试

```bash
# 运行测试
npm test

# 监听模式运行测试
npm run test:watch

# 生成测试覆盖率报告
npm run test:coverage
```

### 构建

```bash
# 构建生产版本
npm run build

# 启动生产服务器
npm start
```

## 配置说明

### 环境变量

主要环境变量说明：

| 变量名 | 说明 | 默认值 |
|--------|------|--------|
| `NODE_ENV` | 运行环境 | `development` |
| `PORT` | 服务端口 | `3000` |
| `DB_HOST` | 数据库主机 | `localhost` |
| `DB_PORT` | 数据库端口 | `5432` |
| `DB_NAME` | 数据库名称 | `vision_insight` |
| `REDIS_HOST` | Redis主机 | `localhost` |
| `REDIS_PORT` | Redis端口 | `6379` |
| `MINIO_ENDPOINT` | MinIO端点 | `localhost` |
| `MINIO_PORT` | MinIO端口 | `9000` |
| `JWT_SECRET` | JWT密钥 | - |

### 数据库配置

数据库连接池配置：

```typescript
{
  host: process.env.DB_HOST,
  port: parseInt(process.env.DB_PORT || '5432'),
  database: process.env.DB_NAME,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  ssl: process.env.DB_SSL === 'true',
  min: parseInt(process.env.DB_POOL_MIN || '2'),
  max: parseInt(process.env.DB_POOL_MAX || '10'),
  idleTimeoutMillis: parseInt(process.env.DB_TIMEOUT || '30000')
}
```

## 部署指南

### 生产环境部署

1. **环境准备**
   - 确保服务器安装了Docker和Docker Compose
   - 配置防火墙规则
   - 准备SSL证书（如需HTTPS）

2. **配置文件**
   - 复制并修改 `.env.example` 为 `.env`
   - 设置强密码和安全密钥
   - 配置生产环境数据库连接

3. **启动服务**
```bash
# 拉取最新镜像
docker-compose pull

# 启动生产环境
docker-compose --profile production up -d
```

4. **监控和维护**
   - 配置日志轮转
   - 设置监控告警
   - 定期备份数据库

### 性能优化

- 启用Redis缓存
- 配置CDN加速静态资源
- 使用负载均衡器
- 优化数据库查询
- 启用Gzip压缩

## 故障排除

### 常见问题

1. **数据库连接失败**
   - 检查数据库服务是否启动
   - 验证连接参数是否正确
   - 确认网络连通性

2. **文件上传失败**
   - 检查MinIO服务状态
   - 验证存储桶权限
   - 确认文件大小限制

3. **认证问题**
   - 检查JWT密钥配置
   - 验证Token有效期
   - 确认用户权限

### 日志查看

```bash
# 查看应用日志
docker-compose logs -f backend

# 查看数据库日志
docker-compose logs -f postgres

# 查看所有服务日志
docker-compose logs -f
```

## 贡献指南

1. Fork项目
2. 创建功能分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 创建Pull Request

## 许可证

本项目采用MIT许可证 - 查看 [LICENSE](LICENSE) 文件了解详情。

## 联系我们

- 项目主页: [GitHub Repository](https://github.com/vision-insight/backend)
- 问题反馈: [Issues](https://github.com/vision-insight/backend/issues)
- 邮箱: support@vision-insight.com

---

**境之视界团队** © 2024