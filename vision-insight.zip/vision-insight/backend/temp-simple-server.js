const express = require('express');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const app = express();
const port = 3002;

// 确保上传目录存在
const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// 配置multer用于文件上传
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ 
  storage: storage,
  limits: {
    fileSize: 10 * 1024 * 1024 // 10MB限制
  },
  fileFilter: (req, file, cb) => {
    // 允许的文件类型
    const allowedTypes = /\.(pdf|doc|docx|txt|md|json|csv|xlsx|xls)$/i;
    if (allowedTypes.test(file.originalname)) {
      cb(null, true);
    } else {
      cb(new Error('不支持的文件类型'));
    }
  }
});

// 中间件
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(uploadDir));

// 健康检查路由
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    message: '境之视界后端服务运行正常',
    timestamp: new Date().toISOString(),
    version: '1.0.0'
  });
});

// 基本API路由
app.get('/api/projects', (req, res) => {
  res.json({
    success: true,
    data: [],
    message: '项目列表获取成功'
  });
});

app.get('/api/analysis', (req, res) => {
  res.json({
    success: true,
    data: {
      businessModel: {
        valueProposition: '为中小企业提供智能化项目分析和投资决策支持',
        targetCustomers: ['中小企业主', '投资机构', '创业者', '咨询顾问']
      }
    },
    message: '分析数据获取成功'
  });
});

// 创建分析任务API
app.post('/api/analysis', (req, res) => {
  try {
    const { projectId, analysisType, templateId, customOptions } = req.body;
    
    if (!projectId || !analysisType) {
      return res.status(400).json({
        success: false,
        message: '项目ID和分析类型不能为空'
      });
    }

    // 生成分析ID
    const analysisId = `analysis_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    // 模拟分析结果
    const analysisResult = {
      id: analysisId,
      projectId: projectId,
      analysisType: analysisType,
      templateId: templateId,
      status: 'completed',
      result: {
        businessModel: {
          valueProposition: customOptions?.fileId ? '基于上传文件分析的价值主张' : '基于项目描述的价值主张',
          targetCustomers: ['目标客户群体1', '目标客户群体2', '目标客户群体3'],
          keyResources: ['核心资源1', '核心资源2', '核心资源3'],
          keyActivities: ['关键活动1', '关键活动2', '关键活动3'],
          keyPartners: ['关键合作伙伴1', '关键合作伙伴2'],
          costStructure: ['主要成本1', '主要成本2', '主要成本3'],
          revenueStreams: ['收入来源1', '收入来源2', '收入来源3'],
          channels: ['销售渠道1', '销售渠道2'],
          customerRelationships: ['客户关系类型1', '客户关系类型2']
        },
        financial: {
          revenue: {
            year1: 1000000,
            year2: 1500000,
            year3: 2200000,
            growth: '预计年增长率50%'
          },
          costs: {
            fixed: 300000,
            variable: 400000,
            total: 700000
          },
          profitability: {
            grossMargin: '60%',
            netMargin: '30%',
            breakEven: '第18个月'
          }
        },
        investment: {
          fundingNeeds: {
            total: 2000000,
            breakdown: {
              product: 800000,
              marketing: 600000,
              operations: 400000,
              reserve: 200000
            }
          },
          riskAssessment: {
            market: '中等风险',
            technology: '低风险',
            competition: '高风险',
            regulatory: '低风险'
          },
          marketOpportunity: {
            size: '100亿人民币',
            growth: '年增长15%',
            penetration: '预计市场份额2%'
          },
          exitStrategy: {
            timeline: '5-7年',
            options: ['IPO', '战略收购', '管理层收购']
          }
        }
      },
      customOptions: customOptions,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    res.json({
      success: true,
      data: analysisResult,
      message: '分析任务创建成功'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: '创建分析任务失败: ' + error.message
    });
  }
});

// 获取分析结果API
app.get('/api/analysis/:analysisId', (req, res) => {
  try {
    const { analysisId } = req.params;
    
    // 模拟获取分析结果
    const analysisResult = {
      id: analysisId,
      projectId: 'default-project',
      analysisType: 'business_model',
      status: 'completed',
      result: {
        businessModel: {
          valueProposition: '基于分析ID获取的价值主张',
          targetCustomers: ['目标客户群体1', '目标客户群体2'],
          keyResources: ['核心资源1', '核心资源2'],
          keyActivities: ['关键活动1', '关键活动2'],
          costStructure: ['成本结构分析'],
          revenueStreams: ['收入来源分析']
        }
      },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    res.json({
      success: true,
      data: analysisResult,
      message: '分析结果获取成功'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: '获取分析结果失败: ' + error.message
    });
  }
});

// 文件上传API
app.post('/api/upload', upload.single('file'), (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: '没有上传文件'
      });
    }

    const fileInfo = {
      id: req.file.filename.split('.')[0],
      originalName: req.file.originalname,
      filename: req.file.filename,
      size: req.file.size,
      mimetype: req.file.mimetype,
      uploadTime: new Date().toISOString(),
      path: `/uploads/${req.file.filename}`
    };

    res.json({
      success: true,
      data: fileInfo,
      message: '文件上传成功'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: '文件上传失败: ' + error.message
    });
  }
});

// 多文件上传API
app.post('/api/upload/multiple', upload.array('files', 10), (req, res) => {
  try {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        success: false,
        message: '没有上传文件'
      });
    }

    const filesInfo = req.files.map(file => ({
      id: file.filename.split('.')[0],
      originalName: file.originalname,
      filename: file.filename,
      size: file.size,
      mimetype: file.mimetype,
      uploadTime: new Date().toISOString(),
      path: `/uploads/${file.filename}`
    }));

    res.json({
      success: true,
      data: filesInfo,
      message: `成功上传 ${req.files.length} 个文件`
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: '文件上传失败: ' + error.message
    });
  }
});

// 文件分析API
app.post('/api/analysis/file/:fileId', (req, res) => {
  try {
    const { fileId } = req.params;
    const { analysisType = 'business_model' } = req.body;

    // 模拟文件分析结果
    const analysisResult = {
      id: `analysis_${Date.now()}`,
      fileId: fileId,
      analysisType: analysisType,
      status: 'completed',
      result: {
        businessModel: {
          valueProposition: '基于上传文件分析的价值主张',
          targetCustomers: ['目标客户群体1', '目标客户群体2'],
          keyResources: ['核心资源1', '核心资源2'],
          keyActivities: ['关键活动1', '关键活动2'],
          costStructure: ['成本结构分析'],
          revenueStreams: ['收入来源分析']
        },
        financial: {
          revenue: '预计收入分析',
          costs: '成本分析',
          profitability: '盈利能力分析'
        },
        investment: {
          fundingNeeds: '资金需求分析',
          riskAssessment: '风险评估',
          marketOpportunity: '市场机会分析'
        }
      },
      createdAt: new Date().toISOString()
    };

    res.json({
      success: true,
      data: analysisResult,
      message: '文件分析完成'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: '文件分析失败: ' + error.message
    });
  }
});

// 获取文件信息API
app.get('/api/files/:fileId', (req, res) => {
  try {
    const { fileId } = req.params;
    
    // 模拟文件信息
    const fileInfo = {
      id: fileId,
      originalName: 'sample_document.pdf',
      filename: `${fileId}.pdf`,
      size: 1024000,
      mimetype: 'application/pdf',
      uploadTime: new Date().toISOString(),
      path: `/uploads/${fileId}.pdf`,
      status: 'uploaded'
    };

    res.json({
      success: true,
      data: fileInfo,
      message: '文件信息获取成功'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: '获取文件信息失败: ' + error.message
    });
  }
});

// 启动服务器
app.listen(port, () => {
  console.log(`🚀 境之视界后端服务已启动`);
  console.log(`📍 服务地址: http://localhost:${port}`);
  console.log(`🏥 健康检查: http://localhost:${port}/api/health`);
});

// 错误处理
process.on('uncaughtException', (err) => {
  console.error('未捕获的异常:', err);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('未处理的Promise拒绝:', reason);
});